@echo off
chcp 65001 >nul
echo Запуск сервера Смурфо-стрелялки...
node server.js
pause
